//-----------------------------------------------------------------------------------
// Gera uma sequencia de numeros positivos aleatorios
// SEM ordem. Os números podem se repetir.
//
// Usa um inteiro longo longo sem sinal valor máximo 18.446.744.073.709.551.615
// Assim podemos testar limites com grande quantidade de dados não repetidos.
//-----------------------------------------------------------------------------------

 
#include <stdio.h>
#include <stdlib.h>
#include <climits>
#include <math.h>

typedef unsigned long long BIGNUMBER;

/*----------------------------------
 * Função para mostrar os limites de 
 * inteiros na versão do compilador.
 *----------------------------------*/
 void imprimeLimites(){
 	printf("Máximo de int = %d\n",INT_MAX);
 	printf("Mínimo de int = %d\n",INT_MIN);
 	printf("Máximo de unsigned int %ud\n",UINT_MAX);
 	
	//Varia se o compilador for de 32 ou de 64 bits.
	printf("Máximo de long=\t%ld\n",LONG_MAX);//
	printf("Mínimo de long=\t%ld\n",LONG_MIN);	
	printf("Máximo de unsigned long=\t%lu\n",ULONG_MAX);

	printf("Mínimo de long long=%lld\n",LLONG_MIN);
	printf("Máximo de long long=%lld\n",LLONG_MAX);
	
	printf("Máximo unsigned long long=%llu\n",ULLONG_MAX);
}

int main(int argc, char **argv){

	if(argc < 3){
		printf("Uso:\n");
		printf("\t./geraAleatorios <nome do arquivo de saída> <quantidade de inteiros>\n\n");
		exit(1);
	}
	FILE *arq;	// declara o ponteiro do tipo FILE.
	arq = fopen(argv[1],"wb"); //abre o arquivo binário para escrita.	
	BIGNUMBER quantidade = atoi(argv[2]);	//segundo argumeto = quantidade

	BIGNUMBER num = rand()*rand();//*rand(); //gera o primeiro numero aleatório entre 0 
	for(BIGNUMBER i=0; i<quantidade; i++){
		fprintf(stderr,"%llu =\t %llu\n",i,num); //imprime na tela. Poder ser redirecionado geraAleatorio ... > saida.txt
		fwrite(&num,sizeof(BIGNUMBER),1,arq);
		num = rand()*rand();//*rand(); //proximo número = um valor aleatório
	}

	fclose(arq);	

}
